http://www.omdbapi.com/?s=guardians+of+the+galaxy&apikey=thewdb 
http://www.omdbapi.com/?i=tt3896198&apikey=thewdb